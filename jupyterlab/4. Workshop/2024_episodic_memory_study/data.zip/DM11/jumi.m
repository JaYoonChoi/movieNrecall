figure;
plot(rand(1,100),rand(1,100),'*');
hold on;
vline(0.5,'r:');
